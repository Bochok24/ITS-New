import { supabase } from './src/supabase.js';

// DOM Elements
const authContainer = document.getElementById('auth-container');
const contentContainer = document.getElementById('content-container');
const loginSection = document.getElementById('login-section');
const registerSection = document.getElementById('register-section');
const loginForm = document.getElementById('login-form');
const registerForm = document.getElementById('register-form');
const showRegisterLink = document.getElementById('show-register');
const showLoginLink = document.getElementById('show-login');
const showLessonsBtn = document.getElementById('show-lessons');
const showScenariosBtn = document.getElementById('show-scenarios');
const showProgressBtn = document.getElementById('show-progress');
const logoutBtn = document.getElementById('logout');
const userEmailSpan = document.getElementById('user-email');
const lessonsContainer = document.getElementById('lessons-container');
const scenariosContainer = document.getElementById('scenarios-container');
const progressContainer = document.getElementById('progress-container');
const adminContainer = document.getElementById('admin-container');
const adminNav = document.getElementById('admin-nav');
const adminLessonsBtn = document.getElementById('admin-lessons');
const adminScenariosBtn = document.getElementById('admin-scenarios');
const adminProgressBtn = document.getElementById('admin-progress');

// Event Listeners
loginForm.addEventListener('submit', handleLogin);
registerForm.addEventListener('submit', handleRegister);
showRegisterLink.addEventListener('click', () => toggleAuthForms('register'));
showLoginLink.addEventListener('click', () => toggleAuthForms('login'));
showLessonsBtn.addEventListener('click', fetchLessons);
showScenariosBtn.addEventListener('click', fetchScenarios);
showProgressBtn.addEventListener('click', fetchProgress);
logoutBtn.addEventListener('click', handleLogout);
adminLessonsBtn.addEventListener('click', fetchLessons);
adminScenariosBtn.addEventListener('click', fetchScenarios);
adminProgressBtn.addEventListener('click', fetchAllUsersProgress);

// Initialize auth state
initializeAuth();

// Auth state subscription
supabase.auth.onAuthStateChange((event, session) => {
  if (event === 'SIGNED_IN') {
    const user = session.user;
    userEmailSpan.textContent = user.email;
    logoutBtn.style.display = 'block';
    userEmailSpan.style.display = 'block';
    showContent();
    checkAdminStatus(user.id);
  } else if (event === 'SIGNED_OUT') {
    userEmailSpan.textContent = '';
    logoutBtn.style.display = 'none';
    userEmailSpan.style.display = 'none';
    showAuth();
  }
});

async function initializeAuth() {
  try {
    const { data: { session }, error } = await supabase.auth.getSession();
    if (error) throw error;

    if (session) {
      const user = session.user;
      userEmailSpan.textContent = user.email;
      logoutBtn.style.display = 'block';
      userEmailSpan.style.display = 'block';
      showContent();
      await checkAdminStatus(user.id);
    } else {
      showAuth();
    }
  } catch (error) {
    console.error('Auth initialization error:', error);
    showAuth();
  }
}

function showAuth() {
  authContainer.style.display = 'block';
  contentContainer.style.display = 'none';
  adminNav.style.display = 'none';
}

function showContent() {
  authContainer.style.display = 'none';
  contentContainer.style.display = 'block';
  // Load initial content
  fetchLessons();
}

function toggleAuthForms(show) {
  if (show === 'register') {
    loginSection.style.display = 'none';
    registerSection.style.display = 'block';
  } else {
    loginSection.style.display = 'block';
    registerSection.style.display = 'none';
  }
}

function showLoading(form) {
  const button = form.querySelector('button[type="submit"]');
  button.disabled = true;
  button.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Loading...';
}

function hideLoading(form, originalButtonHtml) {
  const button = form.querySelector('button[type="submit"]');
  button.disabled = false;
  button.innerHTML = originalButtonHtml;
}

function showError(message, form) {
  // Remove any existing error message
  const existingError = form.querySelector('.error-message');
  if (existingError) {
    existingError.remove();
  }

  const errorDiv = document.createElement('div');
  errorDiv.className = 'error-message bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mt-4';
  errorDiv.innerHTML = `
    <strong class="font-bold">Error!</strong>
    <span class="block sm:inline"> ${message}</span>
  `;
  form.appendChild(errorDiv);
}

async function handleLogin(e) {
  e.preventDefault();
  const originalButtonHtml = e.target.querySelector('button[type="submit"]').innerHTML;
  showLoading(e.target);

  try {
    const email = document.getElementById('login-username').value;
    const password = document.getElementById('login-password').value;

    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) throw error;

    // Clear form
    e.target.reset();
  } catch (error) {
    console.error('Login error:', error);
    showError(error.message, e.target);
  } finally {
    hideLoading(e.target, originalButtonHtml);
  }
}

async function handleRegister(e) {
  e.preventDefault();
  const originalButtonHtml = e.target.querySelector('button[type="submit"]').innerHTML;
  showLoading(e.target);

  try {
    const email = document.getElementById('register-username').value;
    const password = document.getElementById('register-password').value;
    const confirmPassword = document.getElementById('register-confirm-password').value;

    if (password !== confirmPassword) {
      throw new Error('Passwords do not match');
    }

    if (password.length < 6) {
      throw new Error('Password must be at least 6 characters long');
    }

    const { data, error } = await supabase.auth.signUp({
      email,
      password,
    });

    if (error) throw error;

    // Clear form
    e.target.reset();
    
    // Show success message and switch to login
    alert('Registration successful! Please log in with your credentials.');
    toggleAuthForms('login');
  } catch (error) {
    console.error('Registration error:', error);
    showError(error.message, e.target);
  } finally {
    hideLoading(e.target, originalButtonHtml);
  }
}

async function handleLogout() {
  try {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
  } catch (error) {
    console.error('Logout error:', error);
    alert('Error logging out: ' + error.message);
  }
}

async function checkAdminStatus(userId) {
  try {
    const { data: profile, error } = await supabase
      .from('profiles')
      .select('is_admin')
      .eq('id', userId)
      .single();

    if (error) throw error;

    if (profile?.is_admin) {
      adminNav.style.display = 'flex';
    } else {
      adminNav.style.display = 'none';
    }
  } catch (error) {
    console.error('Error checking admin status:', error);
  }
}

function showContainer(container) {
  // Hide all containers first
  lessonsContainer.style.display = 'none';
  scenariosContainer.style.display = 'none';
  progressContainer.style.display = 'none';
  adminContainer.style.display = 'none';

  // Show the selected container
  container.style.display = 'grid';
}

async function fetchLessons() {
  try {
    const { data: lessons, error } = await supabase
      .from('lessons')
      .select('*')
      .order('created_at', { ascending: true });

    if (error) throw error;

    displayLessons(lessons || []);
  } catch (error) {
    console.error('Error fetching lessons:', error);
    lessonsContainer.innerHTML = '<p class="text-red-500">Error loading lessons</p>';
  }
}

async function fetchScenarios() {
  try {
    const { data: scenarios, error } = await supabase
      .from('scenarios')
      .select('*')
      .order('created_at', { ascending: true });

    if (error) throw error;

    displayScenarios(scenarios || []);
  } catch (error) {
    console.error('Error fetching scenarios:', error);
    scenariosContainer.innerHTML = '<p class="text-red-500">Error loading scenarios</p>';
  }
}

async function fetchProgress() {
  try {
    const user = (await supabase.auth.getUser()).data.user;
    const { data: progress, error } = await supabase
      .from('progress')
      .select(`
        *,
        lessons (title),
        scenarios (title)
      `)
      .eq('user_id', user.id);

    if (error) throw error;

    displayProgress(progress || []);
  } catch (error) {
    console.error('Error fetching progress:', error);
    progressContainer.innerHTML = '<p class="text-red-500">Error loading progress</p>';
  }
}

async function fetchAllUsersProgress() {
  try {
    const { data: progress, error } = await supabase
      .from('progress')
      .select(`
        *,
        auth.users (email),
        lessons (title),
        scenarios (title)
      `);

    if (error) throw error;

    displayAllUsersProgress(progress || []);
  } catch (error) {
    console.error('Error fetching all users progress:', error);
    progressContainer.innerHTML = '<p class="text-red-500">Error loading progress data</p>';
  }
}

function displayLessons(lessons) {
  const isAdmin = adminNav.style.display === 'flex';
  
  lessonsContainer.innerHTML = '<h2 class="text-3xl font-bold mb-6 text-center"><i class="fas fa-book-open mr-2"></i>Lessons</h2>';
  
  if (lessons.length === 0) {
    lessonsContainer.innerHTML += '<p class="text-center text-gray-500">No lessons available yet.</p>';
    return;
  }

  lessons.forEach((lesson) => {
    const uploadHtml = isAdmin ? `
      <div class="mt-4">
        <label class="block text-sm font-medium text-gray-700">Upload Media</label>
        <input type="file" 
               accept="video/mp4,image/*" 
               onchange="handleMediaUpload(event, 'lessons', '${lesson.id}')"
               class="mt-1 block w-full text-sm text-gray-500
                      file:mr-4 file:py-2 file:px-4
                      file:rounded-full file:border-0
                      file:text-sm file:font-semibold
                      file:bg-primary file:text-white
                      hover:file:bg-primary-dark">
      </div>
    ` : '';

    lessonsContainer.innerHTML += `
      <div class="card group">
        <div class="flex items-center justify-between mb-4">
          <h3 class="text-xl font-bold text-primary group-hover:text-primary-dark">
            <i class="fas fa-bookmark mr-2"></i>${lesson.title || 'Untitled Lesson'}
          </h3>
          <span class="bg-primary text-white px-3 py-1 rounded-full text-sm">
            <i class="fas fa-clock mr-1"></i>15 min
          </span>
        </div>
        <p class="text-gray-600 mb-4">${lesson.content || 'No content available'}</p>
        ${lesson.media_url ? `
          <div class="relative rounded-lg overflow-hidden mb-4">
            ${lesson.media_url.includes('.mp4') 
              ? `<video src="${lesson.media_url}" controls class="w-full"></video>`
              : `<img src="${lesson.media_url}" alt="${lesson.title}" class="w-full h-48 object-cover">`
            }
          </div>
        ` : ''}
        ${uploadHtml}
        <button class="btn-primary w-full" onclick="startLesson('${lesson.id}')">
          <i class="fas fa-play mr-2"></i>Start Lesson
        </button>
      </div>
    `;
  });
  
  showContainer(lessonsContainer);
}

function displayScenarios(scenarios) {
  const isAdmin = adminNav.style.display === 'flex';
  
  scenariosContainer.innerHTML = '<h2 class="text-3xl font-bold mb-6 text-center"><i class="fas fa-sitemap mr-2"></i>Scenarios</h2>';
  
  if (scenarios.length === 0) {
    scenariosContainer.innerHTML += '<p class="text-center text-gray-500">No scenarios available yet.</p>';
    return;
  }

  scenarios.forEach((scenario) => {
    const uploadHtml = isAdmin ? `
      <div class="mt-4">
        <label class="block text-sm font-medium text-gray-700">Upload Media</label>
        <input type="file" 
               accept="video/mp4,image/*" 
               onchange="handleMediaUpload(event, 'scenarios', '${scenario.id}')"
               class="mt-1 block w-full text-sm text-gray-500
                      file:mr-4 file:py-2 file:px-4
                      file:rounded-full file:border-0
                      file:text-sm file:font-semibold
                      file:bg-primary file:text-white
                      hover:file:bg-primary-dark">
      </div>
    ` : '';

    scenariosContainer.innerHTML += `
      <div class="card group">
        <div class="flex items-center justify-between mb-4">
          <h3 class="text-xl font-bold text-primary group-hover:text-primary-dark">
            <i class="fas fa-sitemap mr-2"></i>${scenario.title || 'Untitled Scenario'}
          </h3>
          <span class="bg-secondary text-white px-3 py-1 rounded-full text-sm">
            <i class="fas fa-clock mr-1"></i>${scenario.difficulty || 'Easy'}
          </span>
        </div>
        <p class="text-gray-600 mb-4">${scenario.description || 'No description available'}</p>
        ${scenario.media_url ? `
          <div class="relative rounded-lg overflow-hidden mb-4">
            ${scenario.media_url.includes('.mp4') 
              ? `<video src="${scenario.media_url}" controls class="w-full"></video>`
              : `<img src="${scenario.media_url}" alt="${scenario.title}" class="w-full h-48 object-cover">`
            }
          </div>
        ` : ''}
        ${uploadHtml}
        <button class="btn-secondary w-full" onclick="startScenario('${scenario.id}')">
          <i class="fas fa-play mr-2"></i>Start Scenario
        </button>
      </div>
    `;
  });
  
  showContainer(scenariosContainer);
}

function displayProgress(progress) {
  progressContainer.innerHTML = `
    <h2 class="text-3xl font-bold mb-6 text-center">
      <i class="fas fa-chart-line mr-2"></i>Your Progress
    </h2>
  `;

  if (progress.length === 0) {
    progressContainer.innerHTML += '<p class="text-center text-gray-500">No progress data available yet. Start taking lessons to track your progress!</p>';
    return;
  }

  const lessonsCompleted = progress.filter(p => p.lesson_id && p.completed).length;
  const scenariosCompleted = progress.filter(p => p.scenario_id && p.completed).length;

  progressContainer.innerHTML += `
    <div class="grid gap-6 md:grid-cols-2">
      <div class="card">
        <h3 class="text-xl font-bold mb-4">Lessons Completed</h3>
        <p class="text-4xl font-bold text-primary">${lessonsCompleted}</p>
      </div>
      <div class="card">
        <h3 class="text-xl font-bold mb-4">Scenarios Completed</h3>
        <p class="text-4xl font-bold text-secondary">${scenariosCompleted}</p>
      </div>
    </div>

    <div class="mt-8">
      <h3 class="text-2xl font-bold mb-4">Recent Activity</h3>
      <div class="space-y-4">
        ${progress.map(p => `
          <div class="card">
            <div class="flex items-center justify-between">
              <div>
                <h4 class="font-bold">${p.lessons?.title || p.scenarios?.title || 'Unknown'}</h4>
                <p class="text-sm text-gray-500">${new Date(p.created_at).toLocaleDateString()}</p>
              </div>
              <span class="px-3 py-1 rounded-full ${p.completed ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}">
                ${p.completed ? 'Completed' : 'In Progress'}
              </span>
            </div>
          </div>
        `).join('')}
      </div>
    </div>
  `;

  showContainer(progressContainer);
}

function displayAllUsersProgress(progress) {
  progressContainer.innerHTML = `
    <h2 class="text-3xl font-bold mb-6 text-center">
      <i class="fas fa-users mr-2"></i>All Users Progress
    </h2>
  `;

  if (progress.length === 0) {
    progressContainer.innerHTML += '<p class="text-center text-gray-500">No progress data available yet.</p>';
    return;
  }

  // Group progress by user
  const userProgress = progress.reduce((acc, p) => {
    const email = p.users?.email || 'Unknown User';
    if (!acc[email]) {
      acc[email] = {
        lessonsCompleted: 0,
        scenariosCompleted: 0,
        activities: []
      };
    }
    
    if (p.completed) {
      if (p.lesson_id) acc[email].lessonsCompleted++;
      if (p.scenario_id) acc[email].scenariosCompleted++;
    }
    
    acc[email].activities.push(p);
    return acc;
  }, {});

  progressContainer.innerHTML += `
    <div class="space-y-8">
      ${Object.entries(userProgress).map(([email, data]) => `
        <div class="card">
          <h3 class="text-xl font-bold mb-4">${email}</h3>
          <div class="grid gap-4 md:grid-cols-2 mb-4">
            <div>
              <p class="text-sm text-gray-500">Lessons Completed</p>
              <p class="text-2xl font-bold text-primary">${data.lessonsCompleted}</p>
            </div>
            <div>
              <p class="text-sm text-gray-500">Scenarios Completed</p>
              <p class="text-2xl font-bold text-secondary">${data.scenariosCompleted}</p>
            </div>
          </div>
          <div class="mt-4">
            <h4 class="font-bold mb-2">Recent Activity</h4>
            <div class="space-y-2">
              ${data.activities.slice(0, 3).map(activity => `
                <div class="flex items-center justify-between text-sm">
                  <span>${activity.lessons?.title || activity.scenarios?.title || 'Unknown'}</span>
                  <span class="px-2 py-1 rounded-full ${activity.completed ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}">
                    ${activity.completed ? 'Completed' : 'In Progress'}
                  </span>
                </div>
              `).join('')}
            </div>
          </div>
        </div>
      `).join('')}
    </div>
  `;

  showContainer(progressContainer);
}

async function uploadFile(file, bucket, path) {
  try {
    if (!file) throw new Error('Please select a file');
    
    // Check file type
    const allowedTypes = ['video/mp4', 'image/jpeg', 'image/png', 'image/gif'];
    if (!allowedTypes.includes(file.type)) {
      throw new Error('Invalid file type. Please upload MP4 video or image files only.');
    }
    
    // Check file size (max 50MB)
    const maxSize = 50 * 1024 * 1024; // 50MB in bytes
    if (file.size > maxSize) {
      throw new Error('File size too large. Maximum size is 50MB.');
    }

    const fileExt = file.name.split('.').pop();
    const fileName = `${Math.random().toString(36).substring(2)}.${fileExt}`;
    const filePath = `${path}/${fileName}`;

    const { data, error } = await supabase.storage
      .from(bucket)
      .upload(filePath, file);

    if (error) throw error;

    const { data: { publicUrl } } = supabase.storage
      .from(bucket)
      .getPublicUrl(filePath);

    return publicUrl;
  } catch (error) {
    console.error('Error uploading file:', error);
    throw error;
  }
}

async function handleMediaUpload(event, type, id) {
  try {
    const file = event.target.files[0];
    const bucket = 'media';
    const path = `${type}/${id}`;
    
    // Show loading state
    event.target.disabled = true;
    const loadingEl = document.createElement('span');
    loadingEl.textContent = ' Uploading...';
    event.target.parentNode.appendChild(loadingEl);

    const publicUrl = await uploadFile(file, bucket, path);

    // Update the media_url in the database
    const { error } = await supabase
      .from(type)
      .update({ media_url: publicUrl })
      .eq('id', id);

    if (error) throw error;

    // Remove loading state and show success
    loadingEl.textContent = ' Upload successful!';
    setTimeout(() => loadingEl.remove(), 2000);
    
    // Refresh the view
    if (type === 'lessons') {
      fetchLessons();
    } else {
      fetchScenarios();
    }
  } catch (error) {
    alert(error.message);
  } finally {
    event.target.disabled = false;
  }
}

async function startLesson(lessonId) {
  try {
    const { data, error } = await supabase
      .from('progress')
      .insert({
        user_id: (await supabase.auth.getUser()).data.user.id,
        lesson_id: lessonId,
        completed: false
      });

    if (error) throw error;
    alert('Lesson started! Good luck!');
  } catch (error) {
    console.error('Error starting lesson:', error);
    alert('Error starting lesson: ' + error.message);
  }
}

async function startScenario(scenarioId) {
  try {
    const { data, error } = await supabase
      .from('progress')
      .insert({
        user_id: (await supabase.auth.getUser()).data.user.id,
        scenario_id: scenarioId,
        completed: false
      });

    if (error) throw error;
    alert('Scenario started! Good luck!');
  } catch (error) {
    console.error('Error starting scenario:', error);
    alert('Error starting scenario: ' + error.message);
  }
}

// Make functions available globally
window.handleMediaUpload = handleMediaUpload;
window.startLesson = startLesson;
window.startScenario = startScenario;