/*
  # Create content tables

  1. New Tables
    - `lessons`
      - `id` (uuid, primary key)
      - `title` (text)
      - `content` (text)
      - `media_url` (text)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
    - `scenarios`
      - `id` (uuid, primary key)
      - `title` (text)
      - `description` (text)
      - `difficulty` (text)
      - `media_url` (text)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
    - `progress`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `lesson_id` (uuid, references lessons)
      - `scenario_id` (uuid, references scenarios)
      - `completed` (boolean)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create lessons table
CREATE TABLE IF NOT EXISTS lessons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  content text,
  media_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create scenarios table
CREATE TABLE IF NOT EXISTS scenarios (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  difficulty text DEFAULT 'Easy',
  media_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create progress table
CREATE TABLE IF NOT EXISTS progress (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  lesson_id uuid REFERENCES lessons,
  scenario_id uuid REFERENCES scenarios,
  completed boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE lessons ENABLE ROW LEVEL SECURITY;
ALTER TABLE scenarios ENABLE ROW LEVEL SECURITY;
ALTER TABLE progress ENABLE ROW LEVEL SECURITY;

-- Lessons policies
CREATE POLICY "Lessons are viewable by everyone"
  ON lessons FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Admins can insert lessons"
  ON lessons FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.is_admin = true
    )
  );

CREATE POLICY "Admins can update lessons"
  ON lessons FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.is_admin = true
    )
  );

-- Scenarios policies
CREATE POLICY "Scenarios are viewable by everyone"
  ON scenarios FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Admins can insert scenarios"
  ON scenarios FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.is_admin = true
    )
  );

CREATE POLICY "Admins can update scenarios"
  ON scenarios FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.is_admin = true
    )
  );

-- Progress policies
CREATE POLICY "Users can view their own progress"
  ON progress FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own progress"
  ON progress FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own progress"
  ON progress FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

-- Add some sample lessons
INSERT INTO lessons (title, content) VALUES
  ('Introduction to First Aid', 'Learn the basics of first aid and emergency response.'),
  ('CPR Basics', 'Understanding the fundamentals of cardiopulmonary resuscitation.'),
  ('Wound Care', 'How to properly clean and dress different types of wounds.');

-- Add some sample scenarios
INSERT INTO scenarios (title, description, difficulty) VALUES
  ('Emergency Response', 'Practice responding to a medical emergency scenario.', 'Easy'),
  ('CPR Emergency', 'Handle a situation requiring immediate CPR.', 'Medium'),
  ('Multiple Injuries', 'Deal with multiple injuries in a complex scenario.', 'Hard');