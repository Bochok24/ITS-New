/*
  # Create storage bucket for media files
  
  1. New Storage Bucket
    - Create a new storage bucket named 'media' for storing lesson and scenario media files
  
  2. Security
    - Enable public access for authenticated users
    - Set up appropriate bucket policies
*/

-- Enable storage
CREATE EXTENSION IF NOT EXISTS "storage" SCHEMA "extensions";

-- Create the storage bucket
INSERT INTO storage.buckets (id, name, public)
VALUES ('media', 'media', true);

-- Create storage policy to allow authenticated uploads
CREATE POLICY "Authenticated users can upload media" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'media');

-- Create storage policy to allow public downloads
CREATE POLICY "Public users can download media" ON storage.objects
  FOR SELECT TO public
  USING (bucket_id = 'media');